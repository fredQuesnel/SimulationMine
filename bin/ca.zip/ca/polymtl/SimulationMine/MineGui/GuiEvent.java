package ca.polymtl.SimulationMine.MineGui;

import java.awt.Event;

public class GuiEvent extends Event {

	
	
	public GuiEvent(Object arg0, int arg1, Object arg2) {
		super(arg0, arg1, arg2);
		// TODO Auto-generated constructor stub
	}

}
